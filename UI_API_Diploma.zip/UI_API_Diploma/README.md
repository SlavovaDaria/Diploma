# UI+ API tests for https://reqres.in/
*UI+API tests covering main functionality of https://reqres.in/ website*

## :hammer_and_wrench: Technology stack:  
<img src="https://github.com/aafanasyevaa/aafanasyevaa/blob/main/media/Java.png" width="60" height="60" /> ***Java*** — `object-oriented programming language`   
<img src="https://github.com/aafanasyevaa/aafanasyevaa/blob/main/media/Selenide.jpg" width="60" height="60" /> ***Selenide*** — `testing framework powered by Selenium WebDriver`  
<img src="https://github.com/aafanasyevaa/aafanasyevaa/blob/main/media/Gradle.png" width="60" height="60" /> ***Gradle*** — `a build automation tool for multi-language software development`  
<img src="https://user-images.githubusercontent.com/93313607/157079979-8b8c967b-b25c-4563-a1e8-1857fac7530a.png" width="60" height="60" />  ***Junit*** — `unit testing framework for the Java programming language`  
<img src="https://github.com/aafanasyevaa/aafanasyevaa/blob/main/media/Jenkins.jpg" width="60" height="50" /> ***Jenkins*** — `open source automation server`  
<img src="https://user-images.githubusercontent.com/93313607/157080106-2d2f6f6d-a969-44b3-bcbf-55743b63f0ae.png" width="60" height="55" /> ***Rest-Assured*** — `Java-based library that is used to test RESTful Web Services`  
<img src="https://user-images.githubusercontent.com/93313607/157080256-bcf26a4c-51c6-45fb-bc69-d896719cc991.png" width="60" height="50" /> ***Allure*** — `Software Quality Management Platform`

***

## :keyboard: Commands to run tests locally
### with remote.properties file
``` gradle clean test ```
### without remote.properties file
``` gradle clean test -Dbrowser=${BROWSER} -DremoteUrl{REMOTE_URL} -DbrowserVersion=${BROWSER_VERSION} -DbrowserSize=${BROWSER_SIZE} ```

***

## :construction_worker_man: Running tests using Jenkins
*You need to set up parameters to run a new job*

 ![image](https://user-images.githubusercontent.com/93313607/154845961-047b09f8-d0d2-4b3d-b340-663768a9b2ff.png)

## :bar_chart: Integration with Alure TestOps
*Allure TestOps allows you to check detailed information about test results*
![image](https://user-images.githubusercontent.com/93313607/154846211-21701fc9-54a2-463a-beef-f5f9bb951cd9.png)

***
## :toolbox: Integration with Jira
*Jira integration is enabled as well*
![image](https://user-images.githubusercontent.com/93313607/154846644-4aedf64b-24bc-4e06-9733-f29c4d16f5c2.png)

***
## :email:Telegram notifications
*Once the test run is over the results are sent to a specified telegram channel*
