package minisiyarova.ui.tests;
import minisiyarova.ui.TestBase;

public class UiTestData extends TestBase {
    public String url = "https://reqres.in/";
}