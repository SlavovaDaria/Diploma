package minisiyarova.api;

public class TestData {
    public final String responseData =  "{ \"id\": 6, \"email\": \"tracey.ramos@reqres.in\", \"first_name\": \"Tracey\", \"last_name\": \"Ramos\", \"avatar\": \"https://reqres.in/img/faces/6-image.jpg\" }";
    public final String expectedEmail = "janet.weaver@reqres.in";
    public final String expectedName = "fuchsia rose";
}

